package com.example.demo.controller;
import com.example.demo.model.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CabRideController {
    
    @GetMapping("/")
    public String showIndex() {
        return "index";
    }
    
    @PostMapping("/calculate")
    public String calculateBillAndPoints(
            @RequestParam double distance,
            @RequestParam int duration,
            Model model) {
        
        CabRide cabRide = new CabRide(distance, duration);
        double bill = CabBillCalculator.calculateBill(cabRide);
        int creditPoints = CreditPointCalculator.computeCreditPoints(bill);
        
        model.addAttribute("bill", bill);
        model.addAttribute("creditPoints", creditPoints);
        
        return "result";
    }
}
