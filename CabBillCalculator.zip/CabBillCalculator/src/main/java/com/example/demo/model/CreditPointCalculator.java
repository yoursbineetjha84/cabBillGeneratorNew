package com.example.demo.model;

public class CreditPointCalculator {
    private static final double CREDIT_POINTS_PER_DOLLAR = 0.1;

    public static int computeCreditPoints(double billAmount) {
        return (int) (billAmount * CREDIT_POINTS_PER_DOLLAR);
    }
}