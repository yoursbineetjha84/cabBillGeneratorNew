package com.example.demo.model;

public class CabBillCalculator {
    private static final double COST_PER_KM = 0.5;
    private static final double COST_PER_MINUTE = 0.1;

    public static double calculateBill(CabRide ride) {
        double distanceCost = ride.getDistance() * COST_PER_KM;
        double durationCost = ride.getDuration() * COST_PER_MINUTE;
        return distanceCost + durationCost;
    }
}