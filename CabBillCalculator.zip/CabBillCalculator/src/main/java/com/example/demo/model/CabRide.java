package com.example.demo.model;

public class CabRide {
    private double distance;
    private int duration; // in minutes

    public CabRide(double distance, int duration) {
        this.distance = distance;
        this.duration = duration;
    }

    public double getDistance() {
        return distance;
    }

    public int getDuration() {
        return duration;
    }
}
